/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import Model.RegisterForm;
import java.sql.*; 


/**
 *
 * @author Administrator
 */
public class registerDao {
    public static int insertData(RegisterForm r)
   {
       int status=0;
   try        
   {   
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3309/krishna","root","");
        System.out.println("connection successfully....");
        
         PreparedStatement ps=con.prepareStatement("insert into register_form (name,email) values (?,?)");
         ps.setString(1, r.getName());
         ps.setString(2, r.getEmail());
         
         status=ps.executeUpdate();
   }
   catch(Exception e)
   {
       System.out.println(e.getMessage());
   }
   return status;
 }
}
